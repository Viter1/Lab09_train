package com.vitech.Lab09_train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab09TrainApplicationTests {

	@Test
	void contextLoads() {
	}

}
