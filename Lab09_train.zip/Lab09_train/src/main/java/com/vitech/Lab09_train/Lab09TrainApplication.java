package com.vitech.Lab09_train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab09TrainApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab09TrainApplication.class, args);
	}

}
